#!/usr/bin/env python

import Part
import math
import numpy

T = 0.5  # 0.5 = bad, 0.1 good
THICKNESS = 1.27 # 1.27 = bad, 12.7 = good,
OFFSET = 0 # 100 = no complainig but still wrong, 0 = error message

def move(pt, angle, dist):
    return (pt[0] + math.cos(math.radians(angle)) * dist,
            pt[1] + math.sin(math.radians(angle)) * dist) + pt[2:]

# evaluates cubic bezier at t, return point
def q(ctrlPoly, t):
    return (1.0-t)**3 * ctrlPoly[0] + 3*(1.0-t)**2 * t * ctrlPoly[1] + 3*(1.0-t)* t**2 * ctrlPoly[2] + t**3 * ctrlPoly[3]

# evaluates cubic bezier first derivative at t, return point
def qprime(ctrlPoly, t):
    return 3*(1.0-t)**2 * (ctrlPoly[1]-ctrlPoly[0]) + 6*(1.0-t) * t * (ctrlPoly[2]-ctrlPoly[1]) + 3*t**2 * (ctrlPoly[3]-ctrlPoly[2])

def perpendicular(vec):
    return numpy.array([-vec[1], vec[0]]) / numpy.linalg.norm(vec)


R = (13*25.4, 15*25.4, 30, 14.5*25.4)
A = move(R, R[2], 1.5*25.4) + (1.5*25.4,)
B = (20.5*25.4, 22.75*25.4, 10, 4*25.4*1.3, -3*25.4)

def iface_endpoints(iface, extra_dist):
    return move(iface, iface[2]+90, iface[3]/2. + extra_dist)

def iface_control_point(iface):
    return move(iface, iface[2], iface[4])

def four_points(A, B):
    return (A, iface_control_point(A), iface_control_point(B), B)

def four_points_endpoints(A, B, extra_dist):
    return four_points(iface_endpoints(A, extra_dist),
                       iface_endpoints(B, extra_dist))

def body_new_sketch(body, sketch_name, plane_name, parts):
    sketch = body.newObject('Sketcher::SketchObject', sketch_name)
    sketch.Support = (body.Document.getObject(plane_name), [''])
    sketch.MapMode = 'FlatFace'
    sketch.Visibility = False
    for p in parts:
        sketch.addGeometry(p)
    return sketch

def build_duct():
    poly0 = [numpy.array(v[:2]) for v in four_points_endpoints(A, B, 0)]
    poly1 = [numpy.array(v[:2]) for v in four_points_endpoints(A, B, THICKNESS)]

    doc = FreeCAD.newDocument()
    body = doc.addObject('PartDesign::Body', 'Body')

    # Primary panel
    sketch = body_new_sketch(body, 'ProfileSketch', 'XZ_Plane',
                             [Part.LineSegment(VV(poly0[0]), VV(poly1[0])),
                              Part.BSplineCurve([VV(x) for x in poly0]),
                              Part.LineSegment(VV(poly0[-1]), VV(poly1[-1])),
                              Part.BSplineCurve([VV(x) for x in poly1])])

    pad = body.newObject('PartDesign::Pad', 'ProfilePad')
    pad.Profile = sketch
    pad.Length = 634.2
    pad.Midplane = 1 # Symmetric
    pad.ReferenceAxis = (sketch, ['N_Axis'])

    # Make primary panel visible
    doc.recompute()
    Gui.activeDocument().activeView().viewTop()
    Gui.SendMsgToActiveView('ViewFit')

    # drill hole in the panel above
    dir = perpendicular(qprime(poly0, T))
    pos = q(poly0, T) + dir * OFFSET
    sketch = body_new_sketch(body, 'ProfileSketch', 'XY_Plane',
                             [Part.Circle(FreeCAD.Vector(0, -306.1),
                                          FreeCAD.Vector(0, 0, 1),
                                          2.5)])
    sketch.AttachmentOffset = FreeCAD.Placement(
        FreeCAD.Vector(pos[0], 0, pos[1]),
        FreeCAD.Rotation(FreeCAD.Vector(0, 1, 0),
                         -20.05847494))

    hole = body.newObject('PartDesign::Pocket', 'Hole')
    hole.Profile = sketch
    hole.Type = 1
    hole.Midplane = 1 # Symmetric
    hole.ReferenceAxis = (sketch, ['N_Axis'])

    # recompute may fail depending on where the hole is
    doc.recompute()



VV = lambda v: FreeCAD.Vector(*v) # take array like [0,1] and call V on the elements like V(0,1)
build_duct()
