import os
from .version import __version__

ICONPATH = os.path.join(os.path.dirname(__file__), "resources", "icons")
