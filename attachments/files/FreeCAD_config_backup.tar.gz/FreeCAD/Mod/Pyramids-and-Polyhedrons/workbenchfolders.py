
# In this file you can add non-standard paths to the actual workbenchfolder 
# in case you have moved or renamed your workbench.

# Your path can start with the classic 'Mod' folder 
# Or from the root.
# Quotes are required, and so are commas



# examples where the workbench is saved in the default Mod folder.

recommended_folders = (
"Mod/Pyramids_and_polyhedrons" ,
"Mod/Pyramids-and-Polyhedrons" ,
"Mod/FreeCAD-Pyramids-and-Polyhedrons" ,
"Mod/Pyramids-and-polyhedrons" 
)


# example of a specific path by a user:

user_chosen_folders = (
"d:\profiles\pasgarci\google drive\EnCours\FreeCad\Macros\Mod\Pyramids-and-Polyhedrons" ,
"d:\profiles\pasgarci\google drive\EnCours\FreeCad\Macros\Mod\FreeCAD-Pyramids-and-Polyhedrons" ,
)
