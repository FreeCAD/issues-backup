# -*- coding: utf-8 -*-
#****************************************************************************
#*                                                                          *
#*  Defeaturing WB for FreeCAD                                              *
#*  Copyright (c) 2018                                                      *
#*  Maurice easyw@katamail.com                                              *
#*                                                                          *
#*  Defeaturing WB           *
#*                                                                          *

