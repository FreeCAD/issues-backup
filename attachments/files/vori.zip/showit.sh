#!/bin/sh

# the two different graphs with similar input

./vori -v -x -.606000000000028  | wc -l
./vori -v -x -.606000000000029  | wc -l

# offset of 28 is one graph
# offset of 29 is the other
#
# the difference is the last two lines of the scaled
# input to the diagram, where in one the last
# segment is of zero length.

./vori -o -x -.606000000000028 > close0.txt
./vori -o -x -.606000000000029 > close1.txt

diff close0.txt close1.txt

tail -2 close0.txt


