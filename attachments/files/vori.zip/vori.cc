#include <unistd.h>
#include <stdlib.h>
#include <math.h>

#include <iostream>
#include <iomanip>
#include <sstream>
#include <limits>
#include <climits>
#include <vector>

#include <boost/polygon/polygon.hpp>
#include <boost/polygon/voronoi.hpp>

using namespace std;
using namespace boost::polygon;

// long and double both seem to work the same
using coordinate_type = long;
using vertex_type = voronoi_vertex<coordinate_type>;
using point_type = point_data<coordinate_type>;
using segment_type = segment_data<coordinate_type>;

using voronoi_diagram_type = voronoi_diagram<double>;

// The edges from which the vd for the right I is built in
// II_test.FCStd
const vector<point_data<double> > rightI =
 { {-24.87, 6.13},
   {-22.796666666666667, 6.155},
   {-19.878333333333334, 6.13},
   {-18.854166666666668, 6.13},
   {-17.9325, 6.769166666666667},
   {-20.313333333333333, 6.948333333333333},
   {-19.772122395833332, 9.294140625},
   {-18.940520833333334, 12.640416666666667},
   {-17.969700520833335, 16.404192708333333},
   {-17.010833333333334, 20.002499999999998},
   {-15.526666666666667, 20.155833333333334},
   {-14.630000000000003, 20.796666666666667},
   {-15.500833333333333, 20.796666666666667},
   {-18.546666666666667, 20.770833333333332},
   {-20.518333333333334, 20.796666666666667},
   {-21.414166666666667, 20.155833333333334},
   {-19.11, 20.002499999999998},
   {-20.207708333333333, 15.526250000000001},
   {-22.054166666666667, 8.305},
   {-22.438333333333333, 6.948333333333333},
   {-23.948333333333334, 6.769166666666667},
   {-24.86999999999997, 6.130000000000022}
 };

// Turns out the only difference is a -10.7066666666667
// shift in x.
const vector<point_data<double> > leftI =
  { {-35.57666666666667, 6.13},
    {-33.50333333333333, 6.155},
    {-30.585, 6.13},
    {-29.560833333333335, 6.13},
    {-28.639166666666668, 6.769166666666667},
    {-31.02, 6.948333333333333},
    {-30.4787890625, 9.294140625},
    {-29.6471875, 12.640416666666667},
    {-28.6763671875, 16.404192708333333},
    {-27.7175, 20.002499999999998},
    {-26.233333333333334, 20.155833333333334},
    {-25.336666666666666, 20.796666666666667},
    {-26.2075, 20.796666666666667},
    {-29.253333333333327, 20.770833333333332},
    {-31.224999999999998, 20.796666666666667},
    {-32.12083333333333, 20.155833333333334},
    {-29.816666666666666, 20.002499999999998},
    {-30.914375, 15.526250000000001},
    {-32.76083333333333, 8.305},
    {-33.144999999999996, 6.948333333333333},
    {-34.655, 6.769166666666667},
    {-35.57666666666663, 6.130000000000022}
  };

template<typename T>
ostream& operator<<(ostream& stream, const voronoi_vertex<T>& vertex) {
  return stream << "v(" << vertex.x() << "," << vertex.y() << ")";
}

template<typename T>
ostream& operator<<(ostream& stream, const point_data<T>& point) {
  return stream << "p(" << point.x() << "," << point.y() << ")";
}

template<typename T>
ostream& operator<<(ostream& stream, const segment_data<T>& segment) {
  return stream << "s(" << low(segment) << " -> " << high(segment) << ")";
}

template<typename T>
ostream& operator<<(ostream& stream, const voronoi_edge<T>& edge) {
  if (edge.is_primary())
    stream << "p";
  else
    stream << "s";

  if (edge.is_curved())
    stream << "c";
  else
    stream << "l";

  stream << "e[";

  if (edge.vertex0())
    stream << *edge.vertex0();
  else
    stream << "inf";

  stream << " -> ";

  if (edge.vertex1())
    stream << *edge.vertex1();
  else
    stream << "inf";

  return stream << "]";
}

map<int, string> source_types =
  {
    {SOURCE_CATEGORY_SINGLE_POINT, "single point"},
    {SOURCE_CATEGORY_SEGMENT_START_POINT, "segment start point"},
    {SOURCE_CATEGORY_SEGMENT_END_POINT, "segment end point"},
    {SOURCE_CATEGORY_INITIAL_SEGMENT, "initial segment"},
    {SOURCE_CATEGORY_REVERSE_SEGMENT, "reverse segment"}
  };

template<typename T>
ostream& operator<<(ostream& stream, const voronoi_cell<T>& cell) {
  if (cell.contains_point())
    stream << "p";
  if (cell.contains_segment())
    stream << "s";
  if (cell.is_degenerate())
    stream << "d";
  stream << "c{" << cell.source_index()
	 << ";";
  auto it = source_types.find(cell.source_category());
  if (it != source_types.end())
    stream << it->second;
  else
    stream << cell.source_category();
  stream << ";0x" << hex << cell.color()
	 << "}";
  return stream;
}

template<typename T>
string cell_data(const vector<point_type>& points,
		 const vector<segment_type>& segments,
		 const voronoi_cell<T>& cell) {
  ostringstream oss;
  oss << setprecision(numeric_limits<double>::digits10);
  const int idx = cell.source_index();
  switch (cell.source_category()) {
  case SOURCE_CATEGORY_SINGLE_POINT:
    oss << points[idx];
    break;
  case SOURCE_CATEGORY_SEGMENT_START_POINT:
    oss << low(segments[idx]);
    break;
  case SOURCE_CATEGORY_SEGMENT_END_POINT:
    oss << high(segments[idx]);
    break;
  case SOURCE_CATEGORY_INITIAL_SEGMENT:
  case SOURCE_CATEGORY_REVERSE_SEGMENT:
    oss << segments[idx];
    break;
  default:
    oss << "Unknown source category " << cell.source_category();
  }
  return oss.str();
}

vector<segment_type> make_segments(const vector<point_data<double> >& points,
				   const point_data<double>& offset,
				   const double scale) {
  vector<segment_type> segments;
  for (size_t idx = 0; idx < points.size()-1; ++idx) {
    point_type start((points[idx].x() + offset.x()) * scale,
		     (points[idx].y() + offset.y()) * scale);
    point_type end((points[idx+1].x() + offset.x()) * scale,
		   (points[idx+1].y() + offset.y()) * scale);
    segments.emplace_back(start, end);
  }
  point_type first((points[0].x() + offset.x()) * scale,
		   (points[0].y() + offset.y()) * scale);
  point_type last((points[points.size()-1].x() + offset.x()) * scale,
		  (points[points.size()-1].y() + offset.y()) * scale);

  segments.emplace_back(last, first);

  return segments;
}

vector<segment_type> make_segments_rounded(const vector<point_data<double> >& points,
					   const point_data<double>& offset,
					   const double scale) {
  vector<segment_type> segments;
  for (size_t idx = 0; idx < points.size()-1; ++idx) {
    point_type start(round((points[idx].x() + offset.x()) * scale),
		     round((points[idx].y() + offset.y()) * scale));
    point_type end(round((points[idx+1].x() + offset.x()) * scale),
		   round((points[idx+1].y() + offset.y()) * scale));
    segments.emplace_back(start, end);
  }
  point_type first(round((points[0].x() + offset.x()) * scale),
		   round((points[0].y() + offset.y()) * scale));
  point_type last(round((points[points.size()-1].x() + offset.x()) * scale),
		  round((points[points.size()-1].y() + offset.y()) * scale));

  segments.emplace_back(last, first);

  return segments;
}

template<typename T>
void voronoi_visualizer_output(const vector<point_data<T> >& points,
			       const vector<segment_data<T> >& segments) {
  cout << points.size() << endl;
  for (size_t idx = 0; idx < points.size(); ++idx)
    cout << points[idx].x() << " " << points[idx].y() << endl;

  cout << segments.size() << endl;
  for (size_t idx = 0; idx < segments.size(); ++idx)
    cout << low(segments[idx]).x()
	 << " " << low(segments[idx]).y()
	 << " " << high(segments[idx]).x()
	 << " " << high(segments[idx]).y() << endl;
}

int main(int argc, char *argv[]) {

  double x_offset = 0;
  double y_offset = 0;
  double scale = 1e3;
  bool inputs = false;
  bool left = false;
  bool cells = false;
  bool edges = false;
  bool vertices = false;
  bool diffs = false;
  bool rounded = false;
  bool output = false; // ouput in voronoi_visualizer format
  int opt;
  while ((opt = getopt(argc, argv, "ordicevlx:y:s:")) != -1) {
    switch (opt) {
    case 'c':
      cells = true;
      break;
    case 'e':
      edges = true;
      break;
    case 'v':
      vertices = true;
      break;
    case 'i':
      inputs = true;
      break;
    case 'd':
      diffs = true;
      break;
    case 'r':
      rounded = true;
      break;
    case 'o':
      output = true;
      break;
    case 'l':
      left = true;
      break;
    case 'x':
      x_offset = atof(optarg);
      break;
    case 'y':
      y_offset = atof(optarg);
      break;
    case 's':
      scale = atof(optarg);
    }
  }

  cout << setprecision(numeric_limits<double>::digits10);

  point_data<double> offset(x_offset, y_offset);

  vector<segment_type> leftI_segments = make_segments(leftI, offset, scale);
  vector<segment_type> rightI_segments = make_segments(rightI, offset, scale);
  if (rounded) {
    vector<segment_type> leftI_segments = make_segments_rounded(leftI, offset, scale);
    vector<segment_type> rightI_segments = make_segments_rounded(rightI, offset, scale);
  }

  if (diffs) {
    for (size_t idx = 0; idx < leftI.size(); ++idx) {
      point_data<double> diff(leftI[idx]);
      deconvolve(diff, rightI[idx]);
      cout << idx << ": " << diff << endl;
    }

    // Again looking at the mapped coordinates
    for (size_t idx = 0; idx < leftI.size(); ++idx) {
      point_type diff0(low(leftI_segments[idx]));
      deconvolve(diff0, low(rightI_segments[idx]));
      point_type diff1(high(leftI_segments[idx]));
      deconvolve(diff1, high(rightI_segments[idx]));
      cout << idx << ": " << diff0 << " " << diff1 << endl;
    }
  }
  
  vector<segment_type> segments = rightI_segments;
  if (left) {
    segments = leftI_segments;
  }

  voronoi_diagram_type vd;

  if (inputs) {
    for (size_t idx = 0; idx < segments.size(); ++idx) {
      cout << segments[idx] << endl;
    }
  }

  vector<point_type> points;

  if (output) {
    // redirect this to a file with a ".txt" extension
    // so voronoi_visualizer will see it
    voronoi_visualizer_output(points, segments);
  }
  
  construct_voronoi(points.begin(), points.end(),
		    segments.begin(), segments.end(), &vd);

  //cout << endl << "Diagram edges:" << endl << endl;

  if (cells) {
    for (voronoi_diagram_type::const_cell_iterator it = vd.cells().begin();
	 it != vd.cells().end(); ++it) {
      cout << *it << endl;
    }
  }
  
  if (edges) {
    for (voronoi_diagram_type::const_edge_iterator it = vd.edges().begin();
	 it != vd.edges().end(); ++it) {
      //    cout << *it << endl;
      if (it->is_primary())
	cout << "p";
      else
	cout << "s";

      if (it->is_curved())
	cout << "c";
      else
	cout << "l";

      cout << "e[";

      if (it->vertex0()) {
	voronoi_vertex v(it->vertex0()->x()/scale - x_offset,
			 it->vertex0()->y()/scale - y_offset);
	cout << v;
      }
      else
	cout << "inf";

      cout << " -> ";

      if (it->vertex1()) {
	voronoi_vertex v(it->vertex1()->x()/scale - x_offset,
			 it->vertex1()->y()/scale - y_offset);
	cout << v;
      }
      else
	cout << "inf";

      cout << "]" << endl;

      cout << "  " << *(it->cell()) << endl;
      cout << "    " << cell_data(points, segments, *(it->cell())) << endl;
      cout << "  " << *(it->twin()->cell()) << endl;
      cout << "    " << cell_data(points, segments, *(it->twin()->cell())) << endl;
    }
  }
  
  if (vertices) {
    for (voronoi_diagram_type::const_vertex_iterator it = vd.vertices().begin();
	 it != vd.vertices().end(); ++it) {
      cout << *it << endl;
    }
  }
  
  return 0;
}
