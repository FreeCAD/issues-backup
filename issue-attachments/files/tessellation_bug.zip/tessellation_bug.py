obj = FreeCAD.ActiveDocument.Objects[0]
print(len(obj.Shape.tessellate(0.01)[0]))
