import os
import FreeCAD, FreeCADGui

exportPath = "C:\\Users\\NicklasNielsen\\Downloads\\test2.png"
imgSize = 10000

# Info
Document = FreeCAD.ActiveDocument
Part = Document.findObjects(Type="App::Part", Label="LMC09-D....-V...")[0]
partNumber = Part.Label


def imageSetup(FreeCADGui):
    FreeCADGui.activateView("Gui::View3DInventor", True)
    FreeCADGui.Selection.clearSelection()
    return FreeCADGui.activeDocument().activeView()


# Export Images
view = imageSetup(FreeCADGui)
# Iso Picture
CutoutBody = Document.findObjects(Type="PartDesign::Body", Label="Cutout")[0]
CutoutBody.Visibility = False
view.viewIsometric()
view.zoomIn()
view.fitAll()
# ColorBuff = CutoutBody.VisibleFeature.ViewObject.DiffuseColor
# CutoutBody.VisibleFeature.ViewObject.DiffuseColor = (1.0, 0.0, 1.0)
CutoutBody.Visibility = True
view.saveImage(exportPath, imgSize, imgSize, "#9D0A9D")
# CutoutBody.VisibleFeature.ViewObject.DiffuseColor = ColorBuff
# Front Picture
CutoutBody.Visibility = False
