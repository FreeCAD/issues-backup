import math
import FreeCAD


import Draft
import Part
import FreeCADGui


RADIUS = 100
Z_MAX = 359
Z_MAX_RADIANS = math.radians(Z_MAX)
ANGLE_INC = 15
ANGLE_INC_RADIANS = math.radians(ANGLE_INC)
ARC_START = -90
ARC_START_RADIANS = math.radians(ARC_START)
ARC_STOP = 90
ARC_STOP_RADIANS = math.radians(ARC_STOP)
Z_AXIS = FreeCAD.Vector(0, 0, 1)

doc = FreeCAD.newDocument()
FreeCADGui.activeDocument().activeView().viewAxometric()

def frange(x, y, jump):
    while x < y:
        yield x
        x += jump


surfaces = []
last_spline = None
first_spline = None
for za in frange(0, Z_MAX_RADIANS, ANGLE_INC_RADIANS):
    print("za={}".format(math.degrees(za)))
    points = []
    for a in frange(ARC_START_RADIANS, ARC_STOP_RADIANS + ANGLE_INC_RADIANS, ANGLE_INC_RADIANS):
        x = RADIUS * math.cos(a)
        z = RADIUS * math.sin(a)
        p = FreeCAD.Vector(x, 0, z)
        points.append(p)
    spline = Draft.makeBSpline(points)
    if za == 0:
        first_spline = spline
    else:
        Draft.rotate(spline, math.degrees(za), axis=Z_AXIS)
        surface = Part.makeRuledSurface(spline.Shape, last_spline.Shape)
        surfaces.append(surface)
    last_spline = spline
surface = Part.makeRuledSurface(first_spline.Shape, last_spline.Shape)
surfaces.append(surface)
# Part.show(surface)
shell = Part.makeShell(surfaces)
solid = Part.makeSolid(shell)
FreeCAD.ActiveDocument.addObject('Part::Feature', "Sphere").Shape = solid
doc.recompute()
FreeCADGui.updateGui()
FreeCADGui.SendMsgToActiveView("ViewFit")