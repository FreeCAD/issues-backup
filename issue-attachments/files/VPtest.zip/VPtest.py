'''Examples for a feature class and its view provider.'''

import FreeCAD, FreeCADGui
from pivy import coin

class FeatureTest:
    def __init__(self, obj):
        '''Add some custom properties to our box feature'''
        FreeCAD.Console.PrintMessage("FeatureTest.__init__" + "\n")
        obj.addProperty("App::PropertyLength", "Height", "Box", "Height of the box").Height = 1.0
        obj.addProperty("App::PropertyLength", "Length", "Box", "Length of the box").Length = 1.0
        obj.addProperty("App::PropertyLength", "Width", "Box", "Width of the box").Width = 1.0
        obj.Proxy = self

    def onChanged(self, obj, prop):
        '''Do something when a property has changed'''
        FreeCAD.Console.PrintMessage("FeatureTest.onChanged, object property: " + str(prop) + "\n")

    def execute(self, obj):
        '''Do something when doing a recomputation, this method is mandatory'''
        FreeCAD.Console.PrintMessage("FeatureTest.execute" + "\n")

class ViewProviderTest:
    def __init__(self, vobj):
        '''Set this object to the proxy object of the actual view provider'''
        FreeCAD.Console.PrintMessage("ViewProviderTest.__init__" + "\n")
        vobj.addProperty("App::PropertyColor","AAAAA", "Box", "AAAAA").AAAAA = (1.0, 0.0, 0.0)
        vobj.addProperty("App::PropertyColor","Color", "Box", "Color of the box").Color = (1.0, 0.0, 0.0)
        vobj.addProperty("App::PropertyColor","TextColor", "Box", "Color of the text").TextColor = (1.0, 0.0, 0.0)
        vobj.addProperty("App::PropertyColor","ZZZZZ", "Box", "ZZZZZ").ZZZZZ = (1.0, 0.0, 0.0)
        vobj.Proxy = self

    def attach(self, vobj):
        '''Setup the scene sub-graph of the view provider, this method is mandatory'''
        FreeCAD.Console.PrintMessage("ViewProviderTest.attach, list of defined view properties: " + ",".join(vobj.PropertiesList) + "\n")
        self.shaded = coin.SoGroup()
        self.scale = coin.SoScale()
        data=coin.SoCube()
        self.shaded.addChild(self.scale)
        self.shaded.addChild(data)
        vobj.addDisplayMode(self.shaded, "Shaded");

    def updateData(self, obj, prop):
        '''If a property of the handled feature has changed we have the chance to handle this here'''
        # fp is the handled feature, prop is the name of the property that has changed
        FreeCAD.Console.PrintMessage("ViewProviderTest.updateData, object property: " + str(prop) + "\n")
        l = obj.getPropertyByName("Length")
        w = obj.getPropertyByName("Width")
        h = obj.getPropertyByName("Height")
        self.scale.scaleFactor.setValue(float(l), float(w), float(h))
        pass

    def getDisplayModes(self, vobj):
        '''Return a list of display modes.'''
        modes=[]
        modes.append("Shaded")
        modes.append("Wireframe")
        return modes

    def getDefaultDisplayMode(self):
        '''Return the name of the default display mode. It must be defined in getDisplayModes.'''
        return "Shaded"

    def setDisplayMode(self, mode):
        '''Map the display mode defined in attach with those defined in getDisplayModes.\
                Since they have the same names nothing needs to be done. This method is optional'''
        return mode

    def onChanged(self, obj, prop):
        '''Here we can do something when a single property got changed'''
        FreeCAD.Console.PrintMessage("ViewProviderTest.onChanged, view property: " + str(prop) + "\n")

    def dumps(self):
        '''When saving the document this object gets stored using Python's json module.\
                Since we have some un-serializable parts here -- the Coin stuff -- we must define this method\
                to return a tuple of all serializable objects or None.'''
        return None

    def loads(self,state):
        '''When restoring the serialized object from document we have the chance to set some internals here.\
                Since no data were serialized nothing needs to be done here.'''
        return None

def makeFeatureTest():
    FreeCAD.Console.PrintMessage("makeFeatureTest" + "\n")
    a=FreeCAD.ActiveDocument.addObject("App::FeaturePython", "Box")
    FeatureTest(a)
    ViewProviderTest(a.ViewObject)

makeFeatureTest()