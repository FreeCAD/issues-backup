#include <unistd.h>
#include <stdlib.h>

#include <iostream>
#include <iomanip>
#include <limits>
#include <climits>
#include <vector>

#include <boost/polygon/polygon.hpp>
#include <boost/polygon/voronoi.hpp>

using namespace std;

// long and double both seem to work the same
#define VTYPE double

using coordinate_type = VTYPE;
using vertex_type = boost::polygon::voronoi_vertex<VTYPE>;
using point_type = boost::polygon::point_data<VTYPE>;
using segment_type = boost::polygon::segment_data<VTYPE>;

using voronoi_diagram_type = boost::polygon::voronoi_diagram<double>;

// The edges from which the vd for the right I is built in
// II_test.FCStd
const vector< boost::polygon::point_data<double> > pts = { {-24.87, 6.13},
				  {-22.796666666666667, 6.155},
				  {-19.878333333333334, 6.13},
				  {-18.854166666666668, 6.13},
				  {-17.9325, 6.769166666666667},
				  {-20.313333333333333, 6.948333333333333},
				  {-19.772122395833332, 9.294140625},
				  {-18.940520833333334, 12.640416666666667},
				  {-17.969700520833335, 16.404192708333333},
				  {-17.010833333333334, 20.002499999999998},
				  {-15.526666666666667, 20.155833333333334},
				  {-14.630000000000003, 20.796666666666667},
				  {-15.500833333333333, 20.796666666666667},
				  {-18.546666666666667, 20.770833333333332},
				  {-20.518333333333334, 20.796666666666667},
				  {-21.414166666666667, 20.155833333333334},
				  {-19.11, 20.002499999999998},
				  {-20.207708333333333, 15.526250000000001},
				  {-22.054166666666667, 8.305},
				  {-22.438333333333333, 6.948333333333333},
				  {-23.948333333333334, 6.769166666666667},
				  {-24.86999999999997, 6.130000000000022}
};
	 
int main(int argc, char *argv[]) {

  double x_offset = 0;
  double y_offset = 0;
  double scale = 1e3;
  int opt;
  while ((opt = getopt(argc, argv, "x:y:s:")) != -1) {
    switch (opt) {
    case 'x':
      x_offset = atof(optarg);
      break;
    case 'y':
      y_offset = atof(optarg);
      break;
    case 's':
      scale = atof(optarg);
    }
  }
  
  vector<segment_type> input_segs;
  for (size_t idx = 0; idx < pts.size()-1; ++idx) {
    point_type start((pts[idx].x() + x_offset) * scale, (pts[idx].y() + y_offset) * scale);
    point_type end((pts[idx+1].x() + x_offset) * scale, (pts[idx+1].y() + y_offset) * scale);
    input_segs.push_back(segment_type(start, end));
  }
  point_type first((pts[0].x() + x_offset) * scale, (pts[0].y() + y_offset) * scale);
  point_type last((pts[pts.size()-1].x() + x_offset) * scale, (pts[pts.size()-1].y() + y_offset) * scale);
  
  input_segs.push_back(segment_type(last, first));

  voronoi_diagram_type vd;

  cout << setprecision(numeric_limits<double>::digits10);
  if (false)
    for (size_t idx = 0; idx < input_segs.size(); ++idx) {
      cout << low(input_segs[idx]).x() << ", " << low(input_segs[idx]).y()
	   << " -> "
	   << high(input_segs[idx]).x() << ", " << high(input_segs[idx]).y()
	   << endl;
    }

  vector<point_type> nulls;
  construct_voronoi(nulls.begin(), nulls.end(), input_segs.begin(), input_segs.end(), &vd);

  //cout << endl << "Diagram edges:" << endl << endl;
  
  for (boost::polygon::voronoi_diagram<double>::const_edge_iterator it = vd.edges().begin();
       it != vd.edges().end(); ++it) {
    if (it->is_primary())
      cout << "primary";
    else
      cout << "secondary";
    if (it->is_curved())
      cout << " curve";
    else
      cout << " line";
    if (it->vertex0()) {
      cout << " v0 " << (it->vertex0()->x()/scale)-x_offset
	   << "," << (it->vertex0()->y()/scale)-y_offset;
    }
    if (it->vertex1()) {
      cout << " v1 " << (it->vertex1()->x()/scale)-x_offset
	   << "," << (it->vertex1()->y()/scale)-y_offset;
    }
    cout << endl;
  }
  
  return 0;
}
